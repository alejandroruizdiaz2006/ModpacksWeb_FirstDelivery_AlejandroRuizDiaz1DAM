

const containers = document.querySelectorAll('.container');


const modal = document.getElementById('modal');
const closeModal = document.getElementById('closeModal');
const videoFrame = document.getElementById('videoFrame');
const videoTitle = document.getElementById('videoTitle');
const videoDescription = document.getElementById('videoDescription');

const videoData = {
    container1: {
        title: 'Better MC',
        description: '¿Listo para la aventura definitiva? Este pack incluye más de 100 misiones y una generación de mundo completamente renovada con biomas espectaculares gracias a mods como Biomas a Plenitud y Geofílico. Está totalmente optimizado, incluye preajustes de sombreadores personalizados y ha overhaulado las fortalezas y strongholds. Enfréntate a nuevos jefes y criaturas con Mowzies Mobs y Cataclismo, explora miles de mazmorras y estructuras nuevas con Cuando las Mazmorras Surgen y Estructuras AdoraBuild, y descubre la dimensión del Aether ampliada con aldeas, Deep Aether y Aether Redux. Disfruta de características de calidad de vida como Piedras de teletransporte y Tómos de XP, un minimapa de Xaero con funciones adicionales y hasta dragones montables. Con más de 350 mods y muchas características personalizadas para una experiencia mejorada, además de la posibilidad de compartir mundos de forma gratuita y integrada, este es el viaje que estabas esperando.',
        url: 'https://www.youtube.com/embed/IF31Rew9RpM?si=inNDOMk62RTTOGvB'
    },
    container2: {
        title: 'RL Craft',
        description: '¿Estás listo para poner a prueba tus habilidades de supervivencia como nunca antes? RL Craft transforma Minecraft por completo en una experiencia de rol hardcore donde cada decisión cuenta. Este pack incluye un sistema de supervivencia extremo con sed, hambre y temperatura realistas, donde deberás luchar contra más de 100 tipos de criaturas mejoradas y jefes aterradores como los dragones de Ice and Fire que pueden destruir paisajes enteros. Tu progreso depende de un sistema de niveles y habilidades que te obliga a especializarte, mientras exploras dungeons generados con Lycanites Mobs que te harán reconsiderar cada exploración. Con mecánicas de construcción realistas donde los bloques pueden colapsar, enfermedades que debes tratar y un combate táctico que premia la estrategia sobre el clickeo rápido, cada partida se convierte en una épica lucha por la supervivencia. ¿Tienes lo que se necesita para sobrevivir en un mundo donde la muerte llega rápido y las consecuencias son permanentes?',
        url: 'https://www.youtube.com/embed/tbRAUWNf-2Y?si=pUDxRVPfQzK2bcyX'
    },
    container3: {
        title: 'Cobbleverse',
        description: '¿Sueñas con ser Maestro Pokémon en Minecraft? Este pack fusiona perfectamente el universo Pokémon con Minecraft, permitiéndote capturar, entrenar y combatir con los 1025 Pokémon oficiales mientras exploras las regiones de Kanto, Johto y Hoenn reconstruidas. Enfréntate a Líderes de Gimnasio animados, desafía a la Elite Four y busca Pokémon Legendarios en estructuras especiales, incluso al Rayquaza Shiny en la dimensión del End. Con mecánicas avanzadas como Mega-Evolución, Movimientos Z y Dinamax, más de 200 Pokémon montables, y la posibilidad de completar tu Living Dex con 1200 espacios en el PC, cada partida se siente como un auténtico juego de Pokémon. Los mobs comunes de Minecraft están desactivados para centrarte en tu aventura Pokémon, con banda sonora personalizada y optimización para multijugador. ¿Listo para convertirte en Leyenda?',
        url: 'https://www.youtube.com/embed/HUD1ltMD2AM?si=pxEQFZIHXLUUI3DL'
    },
    container4: {
        title: 'Linggango',
        description: '¿Buscas un survival único y diferente? Este pack redefine completamente la experiencia de Minecraft con una progresión basada en lingotes únicos que debes descubrir y combinar. Comenzarás con herramientas primitivas que se rompen fácilmente, forzándote a explorar ruinas antiguas y descifrar misteriosas recetas de fabricación para desbloquear metales más avanzados. Cada nuevo lingote descubierto abre posibilidades antes imposibles - desde armas con habilidades especiales hasta mecanismos que transforman el mundo. Con estructuras personalizadas llenas de pistas, un sistema de fabricación que premia la experimentación y criaturas adaptadas a este ecosistema único, cada partida se convierte en una emocionante carrera tecnológica. ¿Podrás dominar todos los lingotes y convertirte en el maestro artesano del mundo de Linggango?',
        url: 'https://www.youtube.com/embed/REWpPquL8qU?si=BNbp6DGMm7Qlw4Im'
    },
    container5: {
        title: 'Prominence II: Hasturian Era',
        description: '¿Buscas un RPG épico dentro de Minecraft? Este pack transforma Minecraft en un auténtico juego de rol con una campaña narrativa dividida en dos arcos: La Invasión del Vacío y la Era Hasturiana. Desarrolla tu personaje único a través de un árbol de talentos volcánico con 16 habilidades pasivas, 5 activas y 100 mejoras de estadísticas, enfrentándote a enemigos que escalan según tu nivel. Forja artefactos legendarios con habilidades únicas y enfréntate a jefes míticos de dificultad infinita en combates donde la muerte tiene consecuencias reales. Con un diseño visual completamente personalizado, sistema de transfiguración para personalizar tu equipo sin perder estadísticas, y progresión que une la historia con tu desarrollo personal, cada partida se siente como una aventura épica. ¿Estás listo para escribir tu leyenda en este mundo de fuego y oscuridad?   ',
        url: 'https://www.youtube.com/embed/4uPmfzcIPQY?si=dfqRnrFqre9BqYO3'
    },
    container6: {
        title: 'Beyond Depth',
        description: '¿Te atreves a explorar las profundidades más oscuras de Minecraft? Este pack transforma el subsuelo en una experiencia de exploración aterradora y fascinante, añadiendo 9 dimensiones subterráneas únicas con biomas, criaturas y recursos que no encontrarás en ningún otro lugar. Comenzando en cuevas superficiales y descendiendo progresivamente hacia reinos lovecraftianos, cada capa presenta nuevos peligros, estructuras antiguas y materiales exóticos que obligan a mejorar tu equipo constantemente. Con mecánicas de iluminación y oxígeno que añaden tensión a la exploración, jefes dimensionales que guardan secretos ancestrales, y una progresión natural que recompensa la valía de los aventureros más temerarios, cada excavación se convierte en una expedición a lo desconocido. ¿Tienes el valor de descender donde nadie más se ha atrevido?',
        url: 'https://www.youtube.com/embed/yBai9purmjQ?si=dHfSt3E1DVe9uwrK'
    }
};

if (containers.length > 0) {
    containers.forEach(container => {
        container.addEventListener('click', () => {


            const info = container.querySelector('.info');
            if (info) {
                info.style.display = 'block';
            }


            const id = container.id;
            const data = videoData[id];
            if (data && modal && videoFrame && videoTitle && videoDescription) {
                videoFrame.src = data.url;
                videoTitle.textContent = data.title;
                videoDescription.textContent = data.description;
                modal.setAttribute('data-source', id);
                modal.style.display = 'flex';
            }
        });
    });
}


if (closeModal) {
    closeModal.addEventListener('click', () => {
        if (modal) {
            modal.style.display = 'none';
            modal.removeAttribute('data-source');
        }
        if (videoFrame) videoFrame.src = '';
    });
}

if (modal) {
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
            if (modal) modal.removeAttribute('data-source');
            if (videoFrame) videoFrame.src = '';
        }
    });
}
